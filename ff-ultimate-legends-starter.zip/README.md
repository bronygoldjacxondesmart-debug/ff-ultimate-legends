# FF Ultimate Legends
Independent React website starter for the FF Ultimate Legends esports platform.

## Current foundation
- Responsive branded homepage
- Competition overview cards
- About section and mobile-friendly layout

## Run locally
Install Node.js, then run `npm install` and `npm run dev`.

## Not connected yet
Authentication, database, player registration, host/referee dashboards, event editing, tournament progression, match reporting, and backups are future development phases. The competition cards are currently display-only placeholders.

Brand: FF Ultimate Legends
Main competition: FF Ultimate Legends Cup
Tagline: Where Legends Compete. Champions Are Made.
